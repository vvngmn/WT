from testlink import TestlinkAPIClient, TestLinkHelper
import time

def getTestResultMap(fullpath):
	xmlfile = open(fullpath)
	xml = xmlfile.read()
	titles = re.findall('.*<test id=".*" name="(.*)">.*',xml)
	results = re.findall('.*</tags>\n.*<status status="(.*)" endtime=[\s\S]*?</status>',xml)
	result_map = {}#id result
	#print (titles, results)
	for title in titles:
		names = title.split(' : ')#testlink id, case name
		status = results[titles.index(title)]
		result_map[names[0]] = status
	xmlfile.close()
	return result_map

def upload_case_results(api, testplanid, buildname, result_map):
	for case_id in result_map.keys():
		res = api.reportTCResult(self, case_id, testplanid, buildname, result_map[case_id], '' )
		if not ('Success' in res):
			raise Exception('Import case(%s) result failed !'%case_id)
	print 'Successfully uploaded all case result to testlink !'

if __name__ == '__main__':
	#retrieve result from output.xml
	if len(sys.argv) != 4:
		print 'Please input 4 parameters: project name, testplan name, build name, fullpath of output.xml'
		print sys.exit()
	print sys.argv
	projName = sys.argv[1]
	testPlanName = sys.argv[2]
	buildName = sys.argv[3]
	robot_result_path = sys.argv[4]
	result_map = getTestResultMap(robot_result_path)
	#upload to testlink
    tlapi = TestLinkHelper().connect(TestlinkAPIClient)
	upload_case_results(tlapi, testPlanName, buildName, result_map)
	